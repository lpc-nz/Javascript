class View { // eslint-disable-line no-unused-vars
    static BLANK() {
        return ' '
    }
    static SPACE() {
        return '&nbsp;'
    }
    static TAB() {
        return '&nbsp;&nbsp;&nbsp;&nbsp;'
    }
    static NEWLINE() {
        return '<br>'
    }
    static clr() {
        document.body.style.fontFamily = '<h1> Courier New /h1>'
        document.body.innerHTML = ''
        document.body.style.backgroundColor = 'aqua'
        document.body.style.TAB 
    }
    static out(newText) {
        document.body.innerHTML += newText
    }
    static add(newText) {
        document.body.innerHTML += View.NEWLINE() + newText
    }
    
}