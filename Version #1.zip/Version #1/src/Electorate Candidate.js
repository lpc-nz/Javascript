class Candidate {
    constructor (familyName, personalName, party, votes) {
      this.fName = familyName
      this.pName = personalName
      this.party = party
      this.votes = votes
    }

    toString () {
      const result = `${this.fName} ${this.pName} ${this.party} ${this.votes}`
      return result
    }
  }
  class Party {
    constructor (partyName, partyVote, percentage){
      this.partyName = partyName
      this.partyVote = partyVote
      this.percentage = percentage
    }
    toString () {
      const result = `${this.partyName} ${this.partyVote} ${this.percentage}`
      return result
    }
  }

  class Electorate {
    constructor () {
      this.electorateName = 'Hutt South'
      this.year = 2017
      this.allMyCandidates = []
      this.allMyParties = []
    }

    addCandidate (familyName, personalName, party, votes) {
      const aCandidate = new Candidate(familyName, personalName, party, votes)
      this.allMyCandidates.push(aCandidate)
    }

    addParty (partyName, partyVote, percentage){
      const aParty = new Party(partyName, partyVote, percentage)
      this.allMyParties.push(aParty)
    }

    sortCandidate () {
      this.allMyCandidates.sort(function (a, b) {
        if (a.fName < b.fName) {
          return -1
        }
        if (a.fName > b.fName) {
          return 1
        }
        return 0
      })
    }

    toString () {
      this.sortCandidate()
      let result = `Electorate ${this.electorateName} in ${this.year} ${View.NEWLINE()}`
      for (const aCandidate of this.allMyCandidates) {
        result += View.TAB() + aCandidate + View.NEWLINE()
      }
      let resultParty = `Electorate Party Valid Votes ${View.NEWLINE()}`
      for (const aParty of this.allMyParties){
        resultParty += View.TAB() + aParty + View.NEWLINE()
      }

      return result
      return resultParty
    }
  }
