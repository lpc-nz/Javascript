describe('ElectorateCandidate', function() {
  
  
  describe('Electorate', function() {
    beforeEach(function() {
      Electorate = new Electorate()
    })
    
    it('should have a .electorateName property', function() {
      expect(Electorate.hasOwnProperty('electorateName')).toBeTruthy()
    })
    
       
  })

  describe('Electorate', function() {
    beforeEach(function() {
      Electorate.addCandidate('ANDERSEN', 'Virginia Ruby', 'Labour Party', '18113')
    })

        
    it('should have one entry in the allMyCandidates array', function () {
      const arraySize = Electorate.allMyCandidates.length
      expect(arraySize).toBe(1)
    })

    it('should have a Candidate in the allMyCandidates array', function () {
      const aCandidate = Electorate.allMyCandidates[0]
      expect(aCandidate instanceof Candidate).toBeTruthy()
    })   
    
  describe('Candidate', function () {
    var aCandidate
    beforeEach(function () {
        aCandidate = Electorate.allMyCandidates[0]
      })
      it('should have a .fName property', function () {
        expect(aCandidate.hasOwnProperty('fName')).toBeTruthy()
      })     
      it('should have a .pName property', function () {
        expect(aCandidate.hasOwnProperty('pName')).toBeTruthy()
      })      
      it('should have a .party property', function () {
        expect(aCandidate.hasOwnProperty('party')).toBeTruthy()
      }) 
      it('should have a .votes property', function () {
        expect(aCandidate.hasOwnProperty('votes')).toBeTruthy()
      })     
          
       
      
    })
    
  })

  describe('a Electorate with 7 Candidates in it', function () {
    beforeEach(function () {
      Electorate.addCandidate('ANDERSEN', 'Virginia Ruby', 'Labour Party', '18113')
      Electorate.addCandidate('BEARMAN-RIEDEL', 'Wilfred Arthur', 'NZ Outdoors Party', '112')
      Electorate.addCandidate('BISHOP', 'Christopher', 'National Party', '19643')
      Electorate.addCandidate('FOX', 'Dorothy Frances', 'Independent', '58')
      Electorate.addCandidate('GUPTA', 'Alok', 'New Zealand First Party', '887')
      Electorate.addCandidate('HORROCKS', 'Virginia Jacqueline Ormond', 'Green Party', '1331')
      Electorate.addCandidate('PARKINS', 'Andrew John', 'ACT New Zealand', '89')
      Electorate.addCandidate('WARWICK', 'Richard Terence', 'The Opportunities Party (TOP)', '792')
    })

    it('should have 7 entries in the allMyCandidates array', function () {
      const arraySize = Electorate.allMyCandidates.length
      expect(arraySize).toBe(14)
    })
    
  })


})
